// This file imports implicit dependencies required by generated code.

//go:build mobile_implicit
// +build mobile_implicit

package main

import (
	_ "golang.org/x/mobile/bind"
	_ "golang.org/x/mobile/bind/java"
	_ "golang.org/x/mobile/bind/objc"
)
