// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: 2022 The Ebitengine Authors

package purego

//go:cgo_import_dynamic _dlopen dlopen "/usr/lib/libSystem.B.dylib"
//go:cgo_import_dynamic _dlsym dlsym "/usr/lib/libSystem.B.dylib"
//go:cgo_import_dynamic _dlerror dlerror "/usr/lib/libSystem.B.dylib"
//go:cgo_import_dynamic _dlclose dlclose "/usr/lib/libSystem.B.dylib"
